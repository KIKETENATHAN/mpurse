
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /home/mpurseco/public_html/vms/resources/views/admin/content.blade.php ENDPATH**/ ?>